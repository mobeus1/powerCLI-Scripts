﻿$root = "root"  
$Passwd = "dontaskme"
$newserv = "10.xx.xx.xx"
Write-Host -Object "fetching content to execute using ssh"
$content = 'C:\Program Files\VMware\Infrastructure\vSphere PowerCLI\content.txt'
foreach ($esxiHost in $newserv) {
Connect-VIServer $esxiHost -User  $root -Password $Passwd
Write-Host -Object "starting ssh services on $esxiHost"
$sshstatus= Get-VMHostService  -VMHost $esxiHost| where {$psitem.key -eq "tsm-ssh"}
if ($sshstatus.Running -eq $False) { 
Get-VMHostService | where {$psitem.key -eq "tsm-ssh"} | Start-VMHostService }
#Hardening Esxi Host using remote ssh
Write-Host -Object "Hardening $esxiHost"
Write-Output "y" | & 'C:\Program Files\VMware\Infrastructure\vSphere PowerCLI\plink.exe' -ssh root@$esxihost -P 22 -pw $passwd -m  $content
#Configuring SysLog
Write-Host -Object "Configuring SysLog on $esxiHost"
Get-AdvancedSetting -Entity $esxiHost -Name Syslog.global.defaultSize |Set-AdvancedSetting -Value 1024 -Confirm:$False
Get-AdvancedSetting -Entity $esxiHost -Name Syslog.global.logDir | Set-AdvancedSetting -Value '[] /folder/log'
Get-AdvancedSetting -Entity $esxiHost -Name Syslog.global.logHost | Set-AdvancedSetting -Value 'udp://10.xx.xx.xx:514' -Confirm:$False
Get-VMHostFirewallException -VMHost $esx -Name "syslog" |Set-VMHostFirewallException -Enabled $true -Confirm:$false
#Configuring NTP Server
Write-Host -Object "Configuring NTP on $esxiHost"
Add-VMHostNtpServer -VMHost 10.50.56.140 -NtpServer 10.16.1.62
Get-VMHostFirewallException -VMHost $esxiHost | where {$_.Name -eq "NTP client"} | Set-VMHostFirewallException -Enabled:$true
#Start NTP client service and set to automatic
Get-VmHostService -VMHost $esxiHost | Where-Object {$_.key -eq "ntpd"} | Start-VMHostService | Set-VMHostService -policy "automatic"
#Configuring Security Policy on Vswitch
Write-Host "Configuring Security Policy on $esxiHost"
Get-VirtualSwitch -Standard -VMHost $esxiHost | Get-SecurityPolicy | Set-SecurityPolicy -MacChanges $false -ForgedTransmits $false -AllowPromiscuous $false
#Configuring EsxiShellTimeOut
Write-Host "Configuring EsxiShellTimeOut on $esxiHost"
Get-AdvancedSetting -Entity $esxiHost -Name UserVars.ESXiShellTimeOut |Set-AdvancedSetting -Value 600 -Confirm:$False

}

